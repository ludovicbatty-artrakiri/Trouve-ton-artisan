#!/bin/bash
# Crée le fichier backend/.env de production pour le compte alwaysdata "artrakiri".
# Usage : bash ~/trouve-ton-artisan/installer.sh
echo "=== Configuration de Trouve ton artisan ! ==="
read -r -s -p "Mot de passe de l'utilisateur MySQL artrakiri_api (rien ne s'affiche, c'est normal) : " P
echo
cat > "$HOME/trouve-ton-artisan/backend/.env" <<CONF
NODE_ENV=production
DB_HOST=mysql-artrakiri.alwaysdata.net
DB_PORT=3306
DB_NAME=artrakiri_tta
DB_USER=artrakiri_api
DB_PASSWORD="$P"
API_KEY=eb3e3fb570cb3d17bec158fff791b1b3d6a741485f22755ceb5beef58249559d
CORS_ORIGIN=https://artrakiri.alwaysdata.net
FRONTEND_DIST=$HOME/trouve-ton-artisan/frontend/dist
SMTP_HOST=
MAIL_FROM="Trouve ton artisan <no-reply@artrakiri.alwaysdata.net>"
CONF
chmod 600 "$HOME/trouve-ton-artisan/backend/.env"
echo "Fichier .env créé."
echo "Test de connexion à la base…"
cd "$HOME/trouve-ton-artisan/backend" && timeout 15 env PORT=8099 IP=127.0.0.1 node server.js 2>&1 | head -2
echo "Si tu vois « Connexion à la base de données établie », c'est bon !"
echo "Va maintenant dans Web > Sites (étape suivante du guide)."
